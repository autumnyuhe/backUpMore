# FFCategories

[![CI Status](https://img.shields.io/travis/fanxiaoApple/FFCategories.svg?style=flat)](https://travis-ci.org/fanxiaoApple/FFCategories)
[![Version](https://img.shields.io/cocoapods/v/FFCategories.svg?style=flat)](https://cocoapods.org/pods/FFCategories)
[![License](https://img.shields.io/cocoapods/l/FFCategories.svg?style=flat)](https://cocoapods.org/pods/FFCategories)
[![Platform](https://img.shields.io/cocoapods/p/FFCategories.svg?style=flat)](https://cocoapods.org/pods/FFCategories)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

FFCategories is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'FFCategories'
```

## Author

fanxiaoApple, XF_MBP@qq.com

## License

FFCategories is available under the MIT license. See the LICENSE file for more info.
